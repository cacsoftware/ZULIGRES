from setuptools import setup

setup(
	name='pyeay',
	version='1.1.20201006',
	packages=['pyeay', 'pyeay.dbcac'],
	url='www.cacsoftwarefacil@gmail.com',
	license='mit',
	author='CAC',
	author_email='Edinson Areniz',
	description='system cac'
)
