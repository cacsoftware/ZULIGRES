# -*- coding: utf-8 -*-

def version():
	la_version = '1.1.20201006'
	return la_version