from setuptools import setup

setup(
	name='pyeay',
	version='2021.02.22',
	packages=['pyeay', 'pyeay.dbcac'],
	url='www.cacsoftwarefacil@gmail.com',
	license='mit',
	author='CAC',
	author_email='Edinson Areniz',
	description='system cac'
)
