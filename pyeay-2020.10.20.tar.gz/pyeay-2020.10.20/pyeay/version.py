# -*- coding: utf-8 -*-

def version():
	"""
	desarrollado por edinson areniz yañez

	:return:
	"""
	la_version = '2020.10.22'
	return la_version
