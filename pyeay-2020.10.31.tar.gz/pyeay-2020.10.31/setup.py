from setuptools import setup

setup(
	name='pyeay',
	version='2020.10.31',
	packages=['pyeay', 'pyeay.dbcac'],
	url='www.cacsoftwarefacil@gmail.com',
	license='mit',
	author='CAC',
	author_email='Edinson Areniz',
	description='system cac'
)
